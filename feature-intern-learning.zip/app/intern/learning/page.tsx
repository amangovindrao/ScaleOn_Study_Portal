"use client";

import { useMemo, useState } from "react";
import { useAuth } from "@/app/lib/auth-context";
import { useCourses, useLearningDashboard, useCertificates } from "./hooks/useLearningData";
import { LearningHeader } from "./components/LearningHeader";
import { LearningStats } from "./components/LearningStats";
import { ContinueLearningCard } from "./components/ContinueLearningCard";
import { CourseCard } from "./components/CourseCard";
import { CertificateCard } from "./components/CertificateCard";
import { CategoryFilter } from "./components/CategoryFilter";
import { SearchBar } from "./components/SearchBar";
import { EmptyState, LoadingSkeleton } from "./components/EmptyState";
import { computeCourseProgress } from "./types";

export default function LearningDashboardPage() {
  const { user } = useAuth();
  const { data: courses, loading: coursesLoading } = useCourses();
  const { data: dashboard, loading: dashboardLoading } = useLearningDashboard();
  const { data: certificates } = useCertificates();

  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [status, setStatus] = useState("");

  const categories = useMemo(() => Array.from(new Set((courses ?? []).map((c) => c.category))), [courses]);

  const filteredCourses = useMemo(() => {
    return (courses ?? []).filter((c) => {
      const matchesSearch = c.title.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = !category || c.category === category;
      const matchesDifficulty = !difficulty || c.difficulty === difficulty;
      const progress = computeCourseProgress(c);
      const statusLabel = progress === 100 ? "completed" : progress > 0 ? "in-progress" : "not-started";
      const matchesStatus = !status || statusLabel === status;
      return matchesSearch && matchesCategory && matchesDifficulty && matchesStatus;
    });
  }, [courses, search, category, difficulty, status]);

  const continueCourse = dashboard?.currentCourseId ? (courses ?? []).find((c) => c.id === dashboard.currentCourseId) : null;
  const continueLesson = continueCourse?.modules.flatMap((m) => m.lessons).find((l) => l.id === dashboard?.currentLessonId);

  const loading = coursesLoading || dashboardLoading;

  return (
    <div className="space-y-6">
      {loading || !dashboard ? (
        <LoadingSkeleton rows={1} />
      ) : (
        <LearningHeader firstName={user?.intern?.fullName?.split(" ")[0] ?? "there"} streak={dashboard.streak} />
      )}

      {dashboard && (
        <LearningStats
          totalXp={dashboard.streak.totalXp}
          totalCertificates={dashboard.totalCertificates}
          completedLessonsCount={dashboard.recentlyCompletedLessons.length}
          overallProgressPercent={dashboard.overallProgressPercent}
        />
      )}

      {continueCourse && continueLesson && (
        <ContinueLearningCard
          courseId={continueCourse.id}
          lessonId={continueLesson.id}
          courseTitle={continueCourse.title}
          lessonTitle={continueLesson.title}
        />
      )}

      <div>
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <SearchBar value={search} onChange={setSearch} />
          <CategoryFilter
            categories={categories}
            selectedCategory={category}
            onCategoryChange={setCategory}
            selectedDifficulty={difficulty}
            onDifficultyChange={setDifficulty}
            selectedStatus={status}
            onStatusChange={setStatus}
          />
        </div>

        {coursesLoading ? (
          <LoadingSkeleton rows={3} />
        ) : filteredCourses.length === 0 ? (
          <EmptyState title="No courses match your filters" subtitle="Try clearing search or filters" />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        )}
      </div>

      {certificates && certificates.length > 0 && (
        <div>
          <h2 className="text-base font-bold text-slate-900 mb-3">Your Certificates</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {certificates.map((cert) => (
              <CertificateCard key={cert.id} certificate={cert} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
